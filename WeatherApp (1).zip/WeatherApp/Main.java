import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
int excepted_length= 2;
       int length =lengthOfLongestSubstring("aab");


        System.out.println(excepted_length==length);  //should be 3, abc
    }


    public static int lengthOfLongestSubstring(String s) {

            char[] cae=s.toCharArray();

            String main="";
            String prior="";
            Set<Character> list=new HashSet<>();




            return Math.max(main.length(),prior.length());}
}






